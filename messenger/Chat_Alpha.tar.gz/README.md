#---------------------------------------- Authors -----------------------------------------------------------#
#Team07
#------------------------------------------------------------------------------------------------------------#

#Anson Do 
#Arian Reyes
#Xianzhang Li
#Adrian Gomez
#Kevin Huang

#-------------------------------------- Version -------------------------------------------------------------#

#Release Version: Alpha

#--------------------------------- Known Bugs in Alpha --------------------------------------------------------#


#--------------------------------------- Date ---------------------------------------------------------------#

#05/31/2020

#-------------------------------- General Instrunctions -----------------------------------------------------#

#Files Included with Install of Program

#------------------------------------------------------------------------------------------------------------#

#COPYRIGHT -----> Author and Copyright
#INSTALL -------> Installation Instructions
#Bin -----------> Binary Directory, -chat (Execuatable File), -server -jpgs and pngs for images for the GUI 
#Doc -----------> Documentation Directory, -Chat UserManual -Chat DevManual
#Src -----------> messagecalls.c server.c 


