#--------------------------- USER/ PLAYER NSTALL-------------------------------#

#1. Run "tar -xvzf Chat_Alpha.tar.gz" on command line

#2. Go to bin folder, in example, "cd bin"

#3. To run type "./server" on command line to run server client

#3. To run type "./chat" on command line to run chat client



#------------------------------ DEV. INSTALL  ------------------------------------#

#1. Run "tar -xvzf Chat_Alpha_src.tar.gz" on command line

#2. To compile the executable do "make all"

#3. go into the bin folder type "./server" first

#4. then inside the bin folder again type "./chat" to open the chat client

