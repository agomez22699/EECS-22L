/*This is the header file for Encrypt.c*/
#ifndef ENCRYPT_H
#define ENCRYPT_H

/*enter a password to get an encrypted password*/
char* encrypt(char* password);

#endif

