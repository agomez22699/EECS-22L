//This is for the Message Area of the GUI
#include <gtk/gtk.h>
#include <gdk/gdkx.h>
#include <stdio.h>
#include <gdk/gdktestutils.h>
#include <string.h>
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <pthread.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <arpa/inet.h>
#define NAME_LEN 15

void fileLogin(char* username, char* password);
void fileUser(char* firstName,char* lastName,char* username, char* password);
char createLogin(int argc, char **argv);
int login_button (GtkButton *LoginButton, GObject *context_object);
int createAccount_button(GtkButton *createButton, GObject *context_object);
int signUp_Button(GtkButton *SignupButton, GObject *context_object);
//int createFile(char* username);
char chatInterface(int argc, char **argv,char *username);
void close_window(GtkWidget *button,gpointer window);
char createNewUser(int argc, char **argv);
void destroy( GtkWidget *widget, gpointer data);
int SendMessageButtonFunction (GtkButton *SendMessageButton, GObject *context_object);

void * doRecieving(void * sockID){

	int clientSocket = *((int *) sockID);

	while(1){

		char data[1024];
		int read = recv(clientSocket,data,1024,0);
		data[read] = '\0';
		printf("%s\n",data);

	}

}

//Widgets for Message Screen
GtkWidget	*window;
GtkWidget	*MessageImage;
GtkWidget	*AddFriendImage;
GtkWidget	*SendMessageImage;
GtkWidget *AddFriendButton;
GtkWidget	*SendMessageButton;
GtkWidget	*layout;
GtkWidget	*ContactsImage;
GtkWidget	*ContactsButton;
GtkWidget	*DeleteImage;
GtkWidget	*DeleteButton;
GtkWidget	*BlockImage;
GtkWidget	*BlockButton;
GtkWidget	*entry1;
GtkWidget *messageBoard;
GtkTextBuffer *buffer;
GtkWidget *vbox;
//GtkWidget *bbox;

//Widgets for Login Screen
GtkWidget	*window2;
GtkWidget	*user_entry;
GtkWidget	*password_entry;
GtkWidget	*LoginGUI;
GtkWidget	*LoginButton;
GtkWidget	*LoginBImage;
GtkWidget	*SignupButton;
GtkWidget	*SignupBImage;

//Widgets for create user screen 
GtkWidget	*window3;
GtkWidget	*fname_entry;
GtkWidget	*lname_entry;
GtkWidget	*new_user_entry;
GtkWidget	*new_pass_entry;
GtkWidget	*createButton;
GtkWidget	*createButtonImage;
GtkWidget	*CreateAccountImage;


//Buttons for Login Screen 
int login_button (GtkButton *LoginButton, GObject *context_object){
    g_print("You clicked login button \n");
    
    //Get username inserted in login screen
    GtkEntry *user_entry = g_object_get_data(context_object,"usernameLogin");
    const  gchar *user_text = gtk_entry_get_text(user_entry);
    //print to verify name
    g_print("Username: %s \n",user_text);
    
    GtkEntry *password_entry = g_object_get_data(context_object,"passwordLogin");
    const  gchar *password_text = gtk_entry_get_text(password_entry);
    g_print("Password: %s \n",password_text);	

    char* username = (char*)gtk_entry_get_text(GTK_ENTRY(user_entry));
    char* password = (char*)gtk_entry_get_text(GTK_ENTRY(password_entry));
    
    fileLogin(username,password);

	//Sam change in here

	/* remove this when the connection done
	int n = write(sockfd,username,strlen(username));
	if( n < 0)
	{
		printf("username empty \n");
	}
	n = 0;
	n = write(sockfd,password,strlen(password))
	if(n < 0)
	{
		printf("password empty\n");
	}
	remove this when the connection done*/
	// end here

	
    //fileUser(username, password);
    gtk_widget_destroy(GTK_WIDGET(window2));
    chatInterface(0,0,username);
    return 1;
}


void fileLogin(char* username, char* password){
//login information is stored here
//information: username,password
//add onto list
  FILE *loginPtr;
  loginPtr = fopen("Login.txt", "w");
  fprintf(loginPtr,"Username: %s\n", username);
  fprintf(loginPtr,"Password: %s\n", password);
  fclose(loginPtr);

}

//int createFile(char* username)
//{
//    char *fname = (char*)malloc(strlen(username)+strlen(".txt")+1);
//    assert(fname);
//    fname=strcpy(fname,username);
//    fname=strcat(fname,".txt");
//    /*if(FileExists(fname)){
//      printf("File already exists/n");    
//      return 0; 
//    }*/
//    FILE *newFile=fopen(fname,"w");
//    assert(newFile);
//    fclose(newFile);
//    free(fname);
//    return 1;
//}
//
//void fileUser(char* firstName,char* lastName,char* username, char* password){
////user information is stored here
////information: username,password,friends
////after first user can make folder with users
//  FILE *userPtr;
//  char *fname = (char*)malloc(strlen(username)+strlen(".txt")+1);
//  fname=strcpy(fname,username);
//  fname=strcat(fname,".txt");
//  userPtr = fopen(fname, "w");
//  //can write user's first and last name
//  fprintf(userPtr,"First: %s\n", firstName);
//  fprintf(userPtr,"Last: %s\n", lastName);
//  fprintf(userPtr,"Username: %s\n", username);
//  fprintf(userPtr,"Password: %s\n", password);
//  fclose(userPtr);
//  free(fname);
//}
int signUp_Button(GtkButton *SignupButton, GObject *context_object){
  g_print("Selected the sign up button\n");
  gtk_widget_destroy(GTK_WIDGET(window2));
  createNewUser(0,0);
  return 1;
}

int createAccount_button(GtkButton *createButton, GObject *context_object){

  g_print("Selected create button\n");  
  
  //retrieves and prints the user's first name
  GtkEntry *fname_entry = g_object_get_data(context_object,"fistNameCreateAccount");
  const  gchar *firstName_text = gtk_entry_get_text(fname_entry);
  g_print("First Name: %s \n", firstName_text);
    
  //retrieves and prints the user's last name
  GtkEntry *lname_entry = g_object_get_data(context_object,"lastNameCreateAccount");
  const  gchar *lastName_text = gtk_entry_get_text(lname_entry);
  g_print("Last Name: %s \n", lastName_text);
    
  //retrieves and prints the user's username
  GtkEntry *new_user_entry = g_object_get_data(context_object,"usernameCreateAccount");
  const  gchar *userLogin_text = gtk_entry_get_text(new_user_entry);
  g_print("Username: %s \n",userLogin_text);
    
  //retrieves and prints the user's password
  GtkEntry *new_pass_entry = g_object_get_data(context_object,"passwordCreateAccount");
  const  gchar *passwordLogin_text = gtk_entry_get_text(new_pass_entry);
  g_print("Password: %s \n", passwordLogin_text);


  char* firstName = (char*)gtk_entry_get_text(GTK_ENTRY(fname_entry));
  char* lastName = (char*)gtk_entry_get_text(GTK_ENTRY(lname_entry));
  char* username = (char*)gtk_entry_get_text(GTK_ENTRY(new_user_entry));
  char* password = (char*)gtk_entry_get_text(GTK_ENTRY(new_pass_entry));

  //Sam change in here

/*  remove this when the connection done
  int n;
  //transfer the firstName
  n = write( sockfd,firstName,strlen(firstName));
  if( n <0)// just for debug
  {
	printf("firstNname error\n");
	n=0;
  }
  //transfer the lastName
  n = write( sockfd,lastName,strlen(lastName));
  if( n <0)// just for debug
  {
	printf("lastNname error\n");
	n=0;
  }
  //transfer the username
  n = write( sockfd,username,strlen(username));
  if( n <0)// just for debug
  {
	printf("userNname error\n");
	n=0;
  }
  //transfer the password
  n = write( sockfd,password,strlen(password));
  if( n <0)// just for debug
  {
	printf("password error\n");
	n=0;
  }

remove this when the connection done */  
  // end here




  
  //fileLogin(username,password);
  //createFile(username);
  //fileUser(firstName,lastName,username, password);//add name stuff
  gtk_widget_destroy(GTK_WIDGET(window3));
  //verification 
  g_print("Congrats you created an account\n");
  chatInterface(0,0,username);
  return 1; 
}

void close_window(GtkWidget *button,gpointer window){

   /* remove this when the connection done
   close(sockfd); // disconnt the with the server

*/

   gtk_widget_destroy(GTK_WIDGET(window));
   gtk_main_quit();
}

void destroy( GtkWidget *widget, gpointer data)
{
   /* remove this when the connection done
   close(sockfd); // disconnt the with the server

*/
   gtk_main_quit ();
}

char createNewUser(int argc, char **argv){
  gtk_init(&argc, &argv);
	//Creating New Window
	window3 = gtk_window_new (GTK_WINDOW_TOPLEVEL);
	gtk_window_set_default_size(GTK_WINDOW(window3), 720, 580);
  //gtk_window_set_resizable(GTK_WINDOW(window3),FALSE);
	gtk_widget_show(GTK_WIDGET(window3));

	//Layout
	layout = gtk_layout_new(NULL, NULL);
	gtk_container_add(GTK_CONTAINER (window3), layout);
	gtk_widget_show(layout);
	
	//Loading Images
	CreateAccountImage = gtk_image_new_from_file ("createAccount.jpg");
	gtk_layout_put(GTK_LAYOUT(layout), CreateAccountImage, 0,0);
	gtk_widget_show(GTK_WIDGET(CreateAccountImage));

	//TextBoxes
	fname_entry = gtk_entry_new();
	gtk_entry_set_width_chars((GtkEntry *) fname_entry, 30);
	gtk_layout_put(GTK_LAYOUT(layout), fname_entry, 389, 120);
	gtk_widget_set_size_request(fname_entry, 250, 50);
  gtk_entry_set_max_length (GTK_ENTRY(fname_entry),NAME_LEN);

	lname_entry = gtk_entry_new();
	gtk_entry_set_width_chars((GtkEntry *) lname_entry, 30);
	gtk_layout_put(GTK_LAYOUT(layout), lname_entry, 389, 180);
	gtk_widget_set_size_request(lname_entry, 250, 50);
  gtk_entry_set_max_length (GTK_ENTRY(lname_entry),NAME_LEN);

	new_user_entry = gtk_entry_new();
	gtk_entry_set_width_chars((GtkEntry *) new_user_entry, 30);
	gtk_layout_put(GTK_LAYOUT(layout), new_user_entry, 389, 240);
	gtk_widget_set_size_request(new_user_entry, 250, 50);
  gtk_entry_set_max_length (GTK_ENTRY(new_user_entry),NAME_LEN);

	new_pass_entry = gtk_entry_new();
	gtk_entry_set_width_chars((GtkEntry *) new_pass_entry, 30);
	gtk_layout_put(GTK_LAYOUT(layout), new_pass_entry, 389, 300);
	gtk_widget_set_size_request(new_pass_entry, 250, 50);
  gtk_entry_set_max_length (GTK_ENTRY(new_pass_entry),NAME_LEN);
 

	//Buttons
	createButtonImage = gtk_image_new_from_file("create.jpg");
	createButton = gtk_button_new();
	gtk_container_add(GTK_CONTAINER(createButton), createButtonImage);
	gtk_layout_put(GTK_LAYOUT(layout), createButton, 290, 500);
	gtk_widget_set_size_request(createButton, 135, 38);

  /*Handling object and set Sign-up button*/
  g_object_set_data(G_OBJECT(createButton),"fistNameCreateAccount",fname_entry);
  g_object_set_data(G_OBJECT(createButton),"lastNameCreateAccount",lname_entry);
  g_object_set_data(G_OBJECT(createButton),"usernameCreateAccount",new_user_entry);
  g_object_set_data(G_OBJECT(createButton),"passwordCreateAccount",new_pass_entry);
  g_signal_connect(GTK_BUTTON(createButton),"clicked",G_CALLBACK(createAccount_button),createButton);
  
  g_signal_connect (window3, "clicked", G_CALLBACK (createAccount_button), createButton);
  /*Makinga login button close*/
  g_object_set_data(G_OBJECT(createButton),"window",window3);   
	gtk_widget_show_all(window3);
 
  gtk_main();
  return 0;

}

char createLogin(int argc, char **argv){
  gtk_init(&argc, &argv);
	//Creating New Window
	window2 = gtk_window_new (GTK_WINDOW_TOPLEVEL);
	g_signal_connect (window2, "destroy", G_CALLBACK (gtk_main_quit), NULL);
	gtk_window_set_default_size(GTK_WINDOW(window2), 720, 580);
  //gtk_window_set_resizable(GTK_WINDOW(window2),FALSE);
	gtk_widget_show(GTK_WIDGET(window2));
 

	//Layout
	layout = gtk_layout_new(NULL, NULL);
	gtk_container_add(GTK_CONTAINER (window2), layout);
	gtk_widget_show(layout);

	//Loading Images
	LoginGUI = gtk_image_new_from_file ("login.jpg");
	gtk_layout_put(GTK_LAYOUT(layout), LoginGUI, 0,0);
	gtk_widget_show(GTK_WIDGET(LoginGUI));

	//Buttons
	LoginBImage = gtk_image_new_from_file("loginButton.jpg");
	LoginButton = gtk_button_new();
	gtk_container_add(GTK_CONTAINER(LoginButton), LoginBImage);
	gtk_layout_put(GTK_LAYOUT(layout), LoginButton, 290, 280);
	gtk_widget_set_size_request(LoginButton, 135, 38);

	SignupBImage = gtk_image_new_from_file("signup.jpg");
	SignupButton = gtk_button_new();
	gtk_container_add(GTK_CONTAINER(SignupButton), SignupBImage);
	gtk_layout_put(GTK_LAYOUT(layout), SignupButton, 290, 330);
	gtk_widget_set_size_request(SignupButton, 135, 38);

	//TextBoxes
	user_entry = gtk_entry_new();
	gtk_entry_set_width_chars((GtkEntry *) user_entry, 30);
	gtk_layout_put(GTK_LAYOUT(layout), user_entry, 233, 150);
	gtk_widget_set_size_request(user_entry, 250, 50);
  gtk_entry_set_max_length (GTK_ENTRY(user_entry),NAME_LEN);

	password_entry = gtk_entry_new();
	gtk_entry_set_width_chars((GtkEntry *) password_entry, 30);
	gtk_layout_put(GTK_LAYOUT(layout), password_entry, 233, 210);
	gtk_widget_set_size_request(password_entry, 250, 50);
  gtk_entry_set_max_length (GTK_ENTRY(password_entry),NAME_LEN);

/********************* Handling data and callback functions ***************************/
  //g_signal_connect(SignupButton,"clicked",G_CALLBACK(open_dialogSignUp),window3); 
  /*Handling object and set Login button*/
  g_object_set_data(G_OBJECT(LoginButton),"usernameLogin",user_entry);
  g_object_set_data(G_OBJECT(LoginButton),"passwordLogin",password_entry);
  g_signal_connect(GTK_BUTTON(LoginButton),"clicked",G_CALLBACK(login_button),LoginButton);
  char *username  = (char*) gtk_entry_get_text(GTK_ENTRY(user_entry));
    

//  /*Handling object and set Sign-up button*/
//  g_object_set_data(G_OBJECT(SignupButton),"fistNameCreateAccount",fname_entry);
//  g_object_set_data(G_OBJECT(SignupButton),"lastNameCreateAccount",lname_entry);
//  g_object_set_data(G_OBJECT(SignupButton),"usernameCreateAccount",new_user_entry);
//  g_object_set_data(G_OBJECT(SignupButton),"passwordCreateAccount",new_pass_entry);
//  g_signal_connect(GTK_BUTTON(SignupButton),"clicked",G_CALLBACK(signUp_Button),SignupButton);

  
  g_signal_connect(GTK_BUTTON(SignupButton),"clicked",G_CALLBACK(signUp_Button),SignupButton);
 
  
  /*Makinga login button close*/
  g_object_set_data(G_OBJECT(LoginButton),"window",window2);   
	gtk_widget_show_all(window2);
  gtk_main();
  return 0;
}


char chatInterface(int argc, char **argv,char *username){
  gtk_init(&argc, &argv);
	//Creating New Window
	window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
	g_signal_connect (window, "destroy", G_CALLBACK (gtk_main_quit), NULL);
	gtk_window_set_default_size(GTK_WINDOW(window), 600, 480);
	//gtk_window_set_resizable (GTK_WINDOW(window), FALSE);
	gtk_widget_show(GTK_WIDGET(window));

	//Layout
	layout = gtk_layout_new(NULL, NULL);
	gtk_container_add(GTK_CONTAINER (window), layout);
	gtk_widget_show(layout);

	//Loading Images
	MessageImage = gtk_image_new_from_file ("messageGUI.jpg");
	gtk_layout_put(GTK_LAYOUT(layout), MessageImage, 0,0);
	gtk_widget_show(GTK_WIDGET(MessageImage));
	
	AddFriendImage = gtk_image_new_from_file("addFriend.jpg");
	AddFriendButton = gtk_button_new();
	gtk_container_add(GTK_CONTAINER(AddFriendButton), AddFriendImage);
	gtk_layout_put(GTK_LAYOUT(layout), AddFriendButton, 7, 440);
	gtk_widget_set_size_request(AddFriendButton, 135, 38); 

	SendMessageImage = gtk_image_new_from_file("sendmessage.jpg");
	SendMessageButton = gtk_button_new();
	gtk_container_add(GTK_CONTAINER(SendMessageButton), SendMessageImage);
	gtk_layout_put(GTK_LAYOUT(layout), SendMessageButton, 535, 440);
	gtk_widget_set_size_request(SendMessageButton, 60, 35);
	
	ContactsImage = gtk_image_new_from_file("contacts.jpg");
	ContactsButton = gtk_button_new();
	gtk_container_add(GTK_CONTAINER(ContactsButton), ContactsImage);
	gtk_layout_put(GTK_LAYOUT(layout), ContactsButton, 15, 50);
	gtk_widget_set_size_request(ContactsButton, 120, 38);

	DeleteImage = gtk_image_new_from_file("delete.jpg");
	DeleteButton = gtk_button_new();
	gtk_container_add(GTK_CONTAINER(DeleteButton), DeleteImage);
	gtk_layout_put(GTK_LAYOUT(layout), DeleteButton, 165, 50);
	gtk_widget_set_size_request(DeleteButton, 50, 30);

	BlockImage = gtk_image_new_from_file("block.jpg");
	BlockButton = gtk_button_new();
	gtk_container_add(GTK_CONTAINER(BlockButton), BlockImage);
	gtk_layout_put(GTK_LAYOUT(layout), BlockButton, 535, 40);
	gtk_widget_set_size_request(BlockButton, 50, 45);

	//Text box entry
	entry1 = gtk_entry_new();
	gtk_entry_set_width_chars((GtkEntry *) entry1, 85);
	gtk_layout_put(GTK_LAYOUT(layout), entry1, 160, 445);
	gtk_widget_set_size_request(entry1, 360, 30);
 
//  //Multi-line TextView
////  vbox = gtk_vbox_new (FALSE, 2);
////  gtk_container_add (GTK_CONTAINER (window), vbox);
//  messageBoard = gtk_text_view_new ();
//  //gtk_text_view_set_editable(GTK_TEXT_VIEW(messageBoard),FALSE);
//  //gtk_text_view_set_cursor_visible(GTK_TEXT_VIEW(messageBoard),TRUE);
//  //vbox = gtk_vbox_new(FALSE,2);
//  gtk_layout_put(GTK_LAYOUT(layout), vbox, 160, 300);
//  gtk_widget_set_size_request(vbox,660,425);

	gtk_widget_show_all(window);
  gtk_main();
  return 0;

}

int main(int argc, char **argv){
  	//g_print("done\n");
	int clientSocket = socket(PF_INET, SOCK_STREAM, 0);

	struct sockaddr_in serverAddr;

	serverAddr.sin_family = AF_INET;
	serverAddr.sin_port = htons(9001);
	serverAddr.sin_addr.s_addr = htonl(INADDR_ANY);

	if(connect(clientSocket, (struct sockaddr*) &serverAddr, sizeof(serverAddr)) == -1){
		printf("ERROR 102\n");
		return 0;
	}

	printf("Connection established with server.\n");

	pthread_t thread;
	pthread_create(&thread, NULL, doRecieving, (void *) &clientSocket );
  	createLogin(argc, argv);
}

