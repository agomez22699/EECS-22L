#---------------------------------------- Authors -----------------------------------------------------------#
#Team07
#------------------------------------------------------------------------------------------------------------#

#Anson Do 
#Arian Reyes
#Xianzhang Li
#Adrian Gomez
#Kevin Huang

#-------------------------------------- Version -------------------------------------------------------------#

#Release Version: Beta

#--------------------------------- (IMPORTANT PLEASE READ) Known Issues/Kinks in Beta -----------------------------#

- ***Please use the three pre-made accounts:
	Usernames: bobs, sallyv, nicks 
	Password: password 
- **Recieved messages will be shown in the terminal with a "INCOMING MESSAGE: " indicator
- Make sure the server and the client are on the same eecs server
- If the server does not display "Server started listening" wait and re-run the executable in a minute
- Max Client ID is 9, when the server displays "Client 10 connected" please restart the server

#--------------------------------------- Features -----------------------------------------------------------#

- Login Verification
- Register new accounts
- Messaging through a server
- Chat history Log
- Name Tag for current person messaging
- Password Encryption
- Server client
- Chess Game Integration
- etc



#--------------------------------------- Date ---------------------------------------------------------------#

#06/07/2020

#-------------------------------- General Instrunctions -----------------------------------------------------#

#Files Included with Install of Program

#------------------------------------------------------------------------------------------------------------#

#COPYRIGHT -----> Author and Copyright
#INSTALL -------> Installation Instructions
#Bin -----------> Binary Directory, -chat (Execuatable File), -server -jpgs and pngs for images for the GUI 
#Doc -----------> Documentation Directory, -Chat UserManual -Chat DevManual
#Src -----------> .C's for compilation


