#--------------------------- USER/ PLAYER NSTALL-------------------------------#

#1. Run "tar -xvzf Chat_Beta.tar.gz" on command line

#2. Go to bin folder, in example, "cd bin"

#3. To run type "./server" on command line to run server client

#3. To run type "./chat" on command line to run chat client



#------------------------------ DEV. INSTALL  ------------------------------------#

#1. Run "tar -xvzf Chat_Beta_src.tar.gz" on command line

#2. To compile and run the server executable do "make servertest" 

#3. To compile and run the chat executable do "make test"

#3. To compile the executables do "make server" and "make chat"

#4. To run manually go to the bin folder with "cd bin" and do "./server" and "./chat" in that order





