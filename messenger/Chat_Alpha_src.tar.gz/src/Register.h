/*This is the header file for Register.c*/
#ifndef REGISTER_H
#define REGISTER_H

int register_user(char first[], char last[], char username[], char password[]);

char* user_pass_verification(char username[], char password[]);

#endif
