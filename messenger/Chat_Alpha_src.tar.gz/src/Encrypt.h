/*This is the header file for Encrypt.c*/
#ifndef ENCRYPT_H
#define ENCRYPT_H

char* encrypt(char* password);

#endif

