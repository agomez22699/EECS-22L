/*This file includes registering for a user and user/pass verfication for log in*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Encrypt.h"

int register_user(char first[], char last[], char username[], char password[])
{
	FILE *fp;

	char username_txt[99];
	strcpy(username_txt,username);
	strcat(username_txt, ".txt");
	fp = fopen(username_txt, "r");	
	if(fp != NULL)
	{
		return 0;
	}
	fp = fopen(username_txt, "w");
	fprintf(fp,"%s ",first);
	fprintf(fp,"%s ",last);
	char* pass = password;
	char* en_pass = encrypt(pass);
	fprintf(fp,"%s",en_pass);

	fclose(fp);
	return 1;
}

char* user_pass_verification(char username[], char password[])
{
	FILE *fp;
	char username_txt[99];
	strcpy(username_txt,username);
	strcat(username_txt, ".txt");
	fp = fopen(username_txt, "r");
	if(fp == NULL)
	{
		return "Invalid username\n";
	}
	char first[99], last[99], pass[2000];
	rewind(fp);
	fscanf(fp,"%s %s %s", first, last, pass);
	char* en_pass = encrypt(password);
	if(strcmp(en_pass,pass) != 0)
	{printf("%s\n%s\n",pass,en_pass);
		return "Invalid password\n";
	}

	fclose(fp);
		
	strcat(first, " ");
	strcat(first, last);	
	char* fullname = malloc(sizeof(first)+1);
	for(int i=0;i<sizeof(first);i++)
	{
		fullname[i] = first[i];
	}
	fullname[sizeof(first)+1] = '\0';

	return fullname;
}

/*Testing*/
/*int main()
{
	char first[10]="hello";
	char last[10]="world";
	char username[20]="registertest";
	char password[15]="helloworld";
	int ru = register_user(first,last,username,password);
	if(ru == 0)
		printf("username already taken!\n");
	else
	{
		char* name;
		name = user_pass_verification(username, password);
		printf("Here is your name: %s\n", name);
	}

	return 0;
}*/

