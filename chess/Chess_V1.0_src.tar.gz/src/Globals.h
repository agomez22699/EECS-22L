#ifndef INCLUDED_GLOBALS_H
#define INCLUDED_GLOBALS_H

extern int boardstate[8][8];
extern int board[8][8];
int checkBoard[8][8];
int playerstart;
int datastate;
int checkmate;
int wlRookMoves;
int wrRookMoves;
int blRookMoves;
int brRookMoves;
int wKingMoves;
int bKingMoves;

#endif 