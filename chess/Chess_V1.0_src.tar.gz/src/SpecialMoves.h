#ifndef SPECIALMOVES_H
#define SPECIALMOVES_H

int kingCheck(int x, int y, int piece);

int checkMate(int piece);

#endif // added to end the if statement
