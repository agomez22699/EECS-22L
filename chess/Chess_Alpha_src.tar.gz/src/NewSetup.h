#ifndef NEWSETUP_H
#define NEWSETUP_H

int gamemode_select( GtkWidget *item, gpointer data);

int feature2_select( GtkWidget *item, gpointer data);

int player1_side( GtkWidget *widget, gpointer data );

static void createSetup( void );

#endif
