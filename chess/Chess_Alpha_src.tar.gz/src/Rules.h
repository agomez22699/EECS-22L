#ifndef RULES_H
#define RULES_H

/*Capturing*/
int piece_capture(PIECE *piece);

/*Checkmate*/
int checkmate(void);

/*Pawn*/
int pawn_movement(PIECE *piece);

int pawn_enpassant(PIECE *piece, PIECE *captured_piece);

int pawn_upgrade(PIECE *piece);

int pawn_checkallrules(PIECE *piece, PIECE *captured_piece);

/*King*/
int king_movement(PIECE *piece);

int king_castling(PIECE *piece);

int king_checkallrules(PIECE *piece);

/*Queen*/
int queen_movement(PIECE *piece);

int queen_checkallrules(PIECE *piece);

/*Bishop*/
int bishop_movement(PIECE *piece);

int bishop_checkallrules(PIECE *piece);

/*Knight*/
int knight_movement(PIECE *piece);

int knight_checkallrules(PIECE *piece);

/*Rook*/
int rook_movement(PIECE *piece);

int rook_castling(PIECE *piece);

int rook_checkallrules(PIECE *piece);

#endif // added to end the if statement
