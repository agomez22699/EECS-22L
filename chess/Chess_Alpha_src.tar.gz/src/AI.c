//File that contains the AI Functionality
#include <stdio.h>
