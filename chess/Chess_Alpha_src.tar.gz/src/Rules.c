/*This file checks for the legal moves of the movement of each piece*/
/*Returning 1: Legal, 0:Illegal*/

/*Capturing*/
int piece_capture(PIECE *piece)
{}

/*Checkmate*/
/*Returns 1 for check and 2 for checkmate,
  -1 and -2 for black,
  0 otherwise*/
int checkmate(void)
{}

/*Pawn*/
/*Assuming white is on the top of the board*/
int pawn_movement(PIECE *piece)
{
  switch(piece->color)
  {
    /*white*/
    case 0:
      if((piece->y_pos == piece->prev_y + 1 && piece->x_pos == piece->prev_x) ||
          (piece->prev_y == 1 && piece->y_pos == piece->prev_y + 2))
      {
        return 1;
      }
      else
      {
        return 0;
      }
      break;
    /*black*/
    case 1:
      if((piece->y_pos == piece->prev_y - 1 && piece->x_pos == piece->prev_x) ||
          (piece->prev_y == 6 && piece->y_pos == piece->prev_y - 2))
      {
        return 1;
      }
      else
      {
        return 0;
      }
      break;
  }
}

int pawn_enpassant(PIECE *piece, PIECE *captured_piece)
{
  switch(piece->color)
  {
    /*white*/
    case 0:
      if(piece->value == 5 &&
          piece->prev_y == 5 &&
          piece->y_pos == piece->prev_y + 1 &&
         abs (piece->x_pos - piece->prev_x) == 1)
      {
        if(captured_piece->value == 5 &&
            abs(captured_piece->prev_y - captured_piece->y_pos) == 2 &&
            abs(captured_piece->x_pos - piece->prev_x) == 1)
        {
          return 1;
        }
        else
        {
          return 0;
        }
      }
      else
      {
        return 0;
      } 
      break;
    /*black*/
    case 1:
      if(piece->value == 5 &&
          piece->prev_y == 4 &&
          piece->y_pos == piece->prev_y - 1 &&
          abs(piece->x_pos - piece->prev_x) == 1)
      {
        if(captured_piece->value == 5 &&
            abs(captured_piece->prev_y - captured_piece->y_pos) == 2 &&
            abs(captured_piece->x_pos - piece->prev_x) == 1)
        {
          return 1;
        }
        else
        {
          return 0;
        }
      }
      else
      {
        return 0;
      } 
      break;
  }
}

/*upgrade options: 1-queen, 2-bishop, 3-knight, 4-rook*/
int pawn_upgrade(PIECE *piece)
{
  switch(piece->color)
  {
    /*white*/
    case(0):
      if(piece->y_pos = 7)
      {
        return 1;
      }
      else
      {
        return 0;
      }
      break;
    /*black*/
    case(1):
      if(piece->y_pos = 0)
      {
        return 1;
      }
      else
      {
        return 0;
      }
  }
}

/*Returning 1: Legal, 0:Illegal, 2:Pawn Upgrade*/
int pawn_checkallrules(PIECE *piece, PIECE *captured_piece)
{
  if(pawn_upgrade == 1)
  {
    return 2;
  }
  else if(pawn_movement(piece) == 1 ||
          pawn_enpassant(piece, captured_piece) == 1)
  {
      retun 1;
  }
  else
  {
    return 0;
  }
}

/*King*/
int king_movement(PIECE *piece)
{
  if(piece->x_pos - piece->prev_x <= 1 &&
      piece->x_pos - piece->prev_x >= -1 &&
      piece->y_pos - piece->prev_y <= 1 &&
      piece->y_pos - piece->prev_y >= -1)
  {
    return 1;
  }
  else
  {
    return 0;
  }
}

int king_castling(PIECE *piece)
{}

int king_checkallrules(PIECE *piece)
{}

/*Queen*/
int queen_movement(PIECE *piece)
{
  if(bishop_movement(piece) == 1 && rook_movement(piece) == 1)
  {
    return 1;
  }
  else
  {
    return 0;
  }
}

int queen_checkallrules(PIECE *piece)
{}

/*Bishop*/
int bishop_movement(PIECE *piece)
{
  if(piece->x_pos - piece->prev_x == piece->y_pos - piece->prev_y)
  {
    return 1;
  }
  else
  {
    return 0;
  }
}

int bishop_checkallrules(PIECE *piece)
{}

/*Knight*/
int knight_movement(PIECE *piece)
{}

int knight_checkallrules(PIECE *piece)
{}

/*Rook*/
int rook_movement(PIECE *piece)
{
  if(piece->x_pos == piece->prev_x && piece->y_pos != piece->prev_y ||
      piece->y_pos == piece->prev_y && piece->x_pos != piece->prev_x)
  {
    return 1;
  }
  else
  {
    return 0;
  }
}

int rook_castling(PIECE *piece)
{}

int rook_checkallrules(PIECE *piece)
{}

