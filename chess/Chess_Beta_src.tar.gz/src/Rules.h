#ifndef RULES_H
#define RULES_H

void CheckPossibleMove(int x, int y, int piece);

int CheckMoveValid(int x, int y, int piece);

#endif // added to end the if statement
