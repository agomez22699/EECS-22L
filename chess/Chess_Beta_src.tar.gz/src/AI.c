//File that contains the AI Functionality
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <gtk/gtk.h>
#include <gdk/gdkx.h>
#include <gdk/gdktestutils.h>

void AI(){

gboolean gdk_test_simulate_button(GtkWindow *window,
                          10,
                          10,
                          NULL,
                          NULL, 
			  GDK_BUTTON_PRESS);

	





}









