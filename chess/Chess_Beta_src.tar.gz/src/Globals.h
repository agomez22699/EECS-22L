#ifndef INCLUDED_GLOBALS_H
#define INCLUDED_GLOBALS_H

extern int boardstate[8][8];
int playerstart;

#endif 