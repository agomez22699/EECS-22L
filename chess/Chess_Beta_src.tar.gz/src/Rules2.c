//#include "Rules.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "Globals.h"

//Taking in first click x and y and the piece value

int board[8][8] = 	{{0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0}};

int move[8][8] = 	{{0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0}};



/*1=pawn,2=knight,3=bishop,4=rook,5=queen,6=king*/

void CheckPossibleMove(int x, int y, int piece){
	
	int prevloc[8][8] = 	{{0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0}};

	
	for(int i=0;i<=8;i++)
	{
		for(int j=0;j<=8;j++)
		{
			board[i][j] = 0;
		}
	}
	/*Bottom side pawn*/
	
	if((piece == 1 && playerstart == 0 )||( piece == -1 && playerstart == 1)){
		if(x == 6 && y == 0)
		{
			board[y-2][x] = 1;
			board[y-1][x] = 1;
			board[y-1][x+1] = 2;
		}
		else if(x == 6 && y == 7)
		{
			board[y-2][x] = 1;
			board[y-1][x] = 1;
			board[y-1][x-1] = 2;
		}
		else if(y == 0)
		{
		        board[y-1][x] = 1;
			board[y-1][x+1] = 2;
		}
		else if(y == 7)
		{
		        board[y-1][x] = 1;
			board[y-1][x-1] = 2;
		}
		else if(y == 6)
                {
			board[y-2][x] = 1;
			board[y-1][x] = 1;
			board[y-1][x+1] = 2;
			board[y-1][x-1] = 2;
		}

		else
		{
			board[y-1][x] = 1;
			board[y-1][x-1] = 2;
			board[y-1][x+1] = 2;
		}
	}
	/*Top side pawn*/
	if((piece == -1 && playerstart == 0)||(piece == 1 && playerstart == 1)){
		if(x == 1 && y == 0)
                {
			board[y+2][x] = 1;
			board[y+1][x] = 1;
			board[y+1][x-1] = 2;
		}
		else if(x == 1 && y == 7)
                {
			board[y+2][x] = 1;
			board[y+1][x] = 1;
			board[y+1][x-1] = 2;
		}
		else if(y == 0)
                {
			board[y+1][x] = 1;
			board[y+1][x+1] = 2;
		}
		else if(y == 7)
                {
			board[y+1][x] = 1;
			board[y+1][x-1] = 2;
		}
		else if(y == 1)
                {
			board[y+2][x] = 1;
			board[y+1][x] = 1;
			board[y+1][x+1] = 2;
			board[y+1][x-1] = 2;
		}
		else
		{
		        board[y+1][x] = 1;
			board[y+1][x+1] = 2;
			board[y+1][x-1] = 2;

		}
	}
	/*Knight*/
	if(abs(piece) == 2){
		if((x-1>=0) && (y-2>=0))  board[y-2][x-1] =1;//top left
		if((x-2>=0) && (y-1>=0))  board[y-1][x-2] =1;
		if((x+1<=7) && (y-2>=0))  board[y-2][x+1] =1;//top right
		if((x+2<=7) && (y-1>=0))  board[y-1][x+2] =1;
		
		if((x-1>=0) && (y+2<=7))  board[y+2][x-1] =1;//bottom left
		if((x-2>=0) && (y+1<=7))  board[y+1][x-2] =1;
		if((x+1<=7) && (y+2<=7))  board[y+2][x+1] =1;//bottom right
		if((x+2<=7) && (y+1<=7))  board[y+1][x+2] =1;
	}

	
		
    	
	/*Bishop*/
	if (abs(piece) == 3){
	board[y][x] = 2; // mark the star location

    	int i=x;
    	int j=y;
    	while((i-1)>=0 && (j-1)>=0){
    		i--;
    		j--;
   	 	board[j][i]=1;
   	}
	
  	 	i=x;
  	 	j=y;
    	while((i-1)>=0 && (j+1)<=7){
    		i--;
    		j++;
    		board[j][i]=1;
    	}

    	i=x;
    	j=y;
    	while((i+1)<=7 && (j-1)>=0){
    	i++;
    	j--;
    	board[j][i]=1;
    	}

    	i=x;
    	j=y;
    	while((i+1)<=7 && (j+1)<=7){
    	i++;
    	j++;
    	board[j][i]=1;
    	}
	}
	/*Rook*/
	if(abs(piece) == 4){
		for(int i=0;i<=7;i++)
		{
			board[y][i] = 1;
			board[i][x] = 1;
		}
		board[y][x] = 0;
	}
	/*Queen*/
	if(abs(piece) == 5){
		for(int i=0;i<=7;i++)
		{
			board[y][i] = 1;
			board[i][x] = 1;
		}
		board[y][x] = 0;
		int i=x;
    		int j=y;
    		while((i-1)>=0 && (j-1)>=0){
    		i--;
    		j--;
   	 	board[j][i]=1;
   		}
	
  	 	i=x;
  	 	j=y;
    		while((i-1)>=0 && (j+1)<=7){
    			i--;
    			j++;
    			board[j][i]=1;
    		}

    		i=x;
    		j=y;
    		while((i+1)<=7 && (j-1)>=0){
    		i++;
    		j--;
    		board[j][i]=1;
    		}

    		i=x;
    		j=y;
    		while((i+1)<=7 && (j+1)<=7){
    		i++;
    		j++;
    		board[j][i]=1;
    		}
	}

	/*King*/
	if(abs(piece) == 6){
		if((x-1>=0) && (y-1>=0))  board[y-1][x-1]=1;
		if((x-1>=0)            )  board[y  ][x-1]=1;
		if((x-1>=0) && (y+1<=7))  board[y+1][x-1]=1;
		if(            (y+1<=7))  board[y+1][x  ]=1;
		if((x+1<=7) && (y+1<=7))  board[y+1][x+1]=1;
        	if((x+1<=7)            )  board[y  ][x+1]=1;
		if((x+1<=7) && (y-1>=0))  board[y-1][x+1]=1;
        	if(            (y-1>=0))  board[y-1][x  ]=1;
	}
	printf("BOARD =\n");
	for(int i=0; i<8; i++) {
      		for(int j=0;j<8;j++) {
        		 printf("%d ", board[i][j]);
         	if(j==7){
            		printf("\n");
         		}
      		}
   	}
	
	prevloc[y][x] = piece;
	printf("PREV LOCATION =\n");
	for(int i=0; i<8; i++) {
      		for(int j=0;j<8;j++) {
        		 printf("%d ", prevloc[i][j]);
         	if(j==7){
            		printf("\n");
         		}
      		}
   	}
	
	//create 2d array in global array of all possible move coordinates

}

//boardstate[y][x];
/*1=valid, 0=invalid*/
int CheckMoveValid(int x, int y, int piece){
	//Check if there are pieces in between the possible moves with the 2d array from the previous function
	printf("BOX CHECK = %d\n", board[y][x]);
	if (piece == 1){
		if (board[y][x] == 1){
	
			if (boardstate[y][x] == 0){
				return 1;
			}
			else{
				return 0;	
			}		
		}
		else if (board[y][x] == 2){
			if (boardstate[y][x] < 0){
				return 1;
			}
			else{
				return 0;
			}
		}
		else{
			return 0;
		}
	}

	if (piece == -1){
		if (board[y][x] == 1){
	
			if (boardstate[y][x] == 0){
				return 1;
			}
			else{
				return 0;	
			}		
		}
		else if (board[y][x] == 2){
			if (boardstate[y][x] > 0){
				return 1;
			}
			else{
				return 0;
			}
		}
		else{
			return 0;
		}

		
	}


	if(piece == 2)
    	{
        	if (board[y][x] == 1){              // check posibale
            		if(boardstate[y][x] <= 0)       //check not the own piece and null 
                		return 1;
            		else 
                		return 0;
        	}
    	}
    	if(piece == -2)
    	{
        	if (board[y][x] == 1){              // check posibale
            		if(boardstate[y][x] >= 0)       //check not the own piece and null 
                		return 1;
            		else 
                		return 0;
        	}
    	}

    	

	

	//bishop
	if(abs(piece) == 3)
	{
		
		if (board[x][y]  !=1) return 0; //check the move on the track or not
						// if the x y at the track we dont need to care about board[][]
		
		// find the start point						
		int x_star=0;    
		int y_star=0;
		for(int ii=0;ii<7;ii++){
			for(int yy=0;yy<7;yy++){
				if (board[ii][yy] == 2){
					x_star =ii;
					y_star=yy;
				}
			}
			
		}
			
		//check if there are the piecee befor the x and y
		if( x_star > x && y_star > y){                                                              	// if the x and y at the top left
			while(x_star-1 >=0 && y_star -1 >=0){ 
				if((boardstate[x_star][x_star] >=0) && (x_star !=x && y_star !=y) ) {
					return 0; 
				}  										//find a piece befor the x and y, if <0 means find the ownpiece, "x_star !=x && y_star !=y" for ignor the sameplace click( twice click at the same location)
				if(x_star ==x && y_star ==y){
					 return 1; // did not find the piece 
				}
				x_star--;
				y_star--;
				
			}
				
				
		}else if ( x_star < x && y_star > y){		 // if the x and y at the topright 
			while(x_star+1 <=7 && y_star -1 >=0){   // nor sure is 7 or 8
				if((boardstate[x_star][x_star] >=0) && (x_star !=x && y_star !=y)){ 
					return 0;   //find a piece befor the x and y
				}
				if(x_star ==x && y_star ==y){
					 return 1; // did not find the piece 
				}		
				x_star++;
				y_star--;
			}

		}else if ( x_star > x && y_star < y){		 // if the x and y at the bottomleft 
			while(x_star-1 >=0 && y_star +1 <=7){    // nor sure is 7 or 8
				if((boardstate[x_star][x_star] >=0) && (x_star !=x && y_star !=y)) {
				return 0;
				}   //find a piece befor the x and y
				if(x_star ==x && y_star ==y){
					 return 1; // did not find the piece 
				}
				x_star--;
				y_star++;
			}	
		}else if ( x_star < x && y_star < y){		 // if the x and y at the bottomright
			while(x_star+1 <=7 && y_star +1 <=7){    // nor sure is 7 or 8
				if((boardstate[x_star][x_star] >=0) && (x_star !=x && y_star !=y)){
					 return 0;   //find a piece befor the x and y
				}
				if(x_star ==x && y_star ==y){
				 return 1; // did not find the piece 
				}
				x_star++;
				y_star++;
		}
	

	}

	}
	if(piece == 4)
    	{
        if (board[y][x] != 1) return 0;              // check posibale

        // find the star point
        int x_star=0;
        int y_star=0;
        for(int ii=0;ii<7;ii++){
            for(int yy=0;yy<7;yy++){
                if (board[ii][yy] == 2){
                    x_star =ii;
                    y_star=yy;
                }
            }

        }
        //left side
        if(y_star == y && x_star > x){
            for(int i= x_star -x; i>=0;i--){
                if(( boardstate[y][i] < 0 ) && (x_star !=x && y_star !=y) ) return 0; // <0 mean did not meet with the own piece 
                if( x_star ==x && y_star ==y) return 1; 
            }

        }else if (y_star == y && x_star < x ){ // right side
            for(int i= x-x_star; i>=0;i--){
                if(( boardstate[y][i] < 0 ) && (x_star !=x && y_star !=y) ) return 0; // <0 mean did not meet with the own piece 
                if( x_star ==x && y_star ==y) return 1; 
            }
        }else if (y_star > y && x_star == x){ //top side
            for(int i= y_star=y; i>=0;i--){
                if(( boardstate[i][x] < 0 ) && (x_star !=x && y_star !=y) ) return 0; // <0 mean did not meet with the own piece 
                if( x_star ==x && y_star ==y) return 1; 
            }
        }else if(y_star < y && x_star == x)
            for(int i= y_star=y; i>=0;i--){
                if(( boardstate[i][x] < 0 ) && (x_star !=x && y_star !=y) ) return 0; // <0 mean did not meet with the own piece 
                if( x_star ==x && y_star ==y) return 1; 
            }






    }

	if(piece == 6)
        {
            if (board[y][x] != 1){ 
		return 0; 
		}              // check posibale
            if(boardstate[y][x] <= 0){       //check not the own piece and null 
      		return 1;
		}
            else{ 
                return 0;
		}

        }
        if(piece == -6)
        {
            if (board[y][x] != 1){ 
		return 0; 
		}// check posibale
            if(boardstate[y][x] >= 0)       // check there not the ownpiece
                    {
			return 1;
			}
                else 
                    {
		return 0;
		}

        }    	
}






	








//TESTING PURPOSES
/*int main(){
	int i, j;
	int bboardstate[8][8] = {{-4,-2,-3,-6,-5,-3,-2,-4}, // Initial Board State
				{-1,-1,-1,-1,-1,-1,-1,-1},
				{0,0,0,0,0,0,0,0},
				{0,0,0,0,0,0,0,0},
				{0,0,0,0,0,0,0,0},
				{0,0,0,0,0,0,0,0},
 				{1, 1, 1, 1, 1, 1, 1, 1},
				{ 4, 2, 3, 6, 5, 3, 2, 4}};
	
	CheckPossibleMove(6, 0, 1);

   	for(i=0; i<8; i++) {
      		for(j=0;j<8;j++) {
        		 printf("%d ", board[i][j]);
         	if(j==7){
            		printf("\n");
         		}
      		}
   	}

	
	return 0;
}*/
