#ifndef RULES2_H
#define RULES2_H

void CheckPossibleMove(int x, int y, int piece);

int kingCheck(int y, int x, int piece);

int CheckMoveValid(int x, int y, int piece);

#endif // added to end the if statement
