#--------------------- Authors ----------------------------#

                      #Team07

#----------------------------------------------------------#

#Members:
#Anson Do 
#Arian Reyes
#Xianzhang Li
#Adrian Gomez
#Kevin Huang


#ZotMeUp© 2020

#Usage of the Chess Photo was granted by Pexels.com and user Pixabay.

#Glossary definitions were from EECS 22L Project 1 Slides 1.2 & 1.3

#Graphic of Game Board were from EECS 22L Project 1 Slide 4.1

#Goals of Chess were from https://www.flyordie.com/games/help/chess/en/games_rules_chess.html

#All rights reserved. This program and the accompanying materials are made available by ZotMeUp©. Illegal distribution of this software is forbidden.

#https://freesvg.org/ 
#	--For all Images used for Pieces and Board on page 9. 

