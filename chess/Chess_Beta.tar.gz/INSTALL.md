#--------------------------- USER/ PLAYER NSTALL-------------------------------#

#1. Run "tar -xvzf Chess_Beta.tar.gz" on command line

#2. Go to bin folder, in example, "cd bin"

#3. To compile, run "./chess" on command line



#------------------------------ DEV. INSTALL  ------------------------------------#

#1. Run "tar -xvzf Chess_Beta_src.tar.gz" on command line

#2. To compile the executable do "make all"

#3. To compile and run the executable do "make test"

