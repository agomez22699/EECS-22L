#--------------------------- USER/ PLAYER NSTALL-------------------------------#

#1. Run tar -xvzf Chess_Alpha.tar.gz on command line

#2. Go to bin folder, IE cd bin

#3. To compile, run ./chess on command line



#------------------------------ DEV. INSTALL  ------------------------------------#

#1. Run tar -xvzf Chess_Alpha_src.tar.gz on command line

#2. To compile the executable do "make all"

#3. To compile and run the executable do "make test"

