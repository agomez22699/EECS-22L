#--------------------- Authors -------------------------------------------------#

#Team07
#-------------------------------------------------------------------------------#

#Anson Do 
#Arian Reyes
#Xianzhang Li
#Adrian Gomez
#Kevin Huang

#--------------------- Version --------------------------------------------------#

#Alpha Release Version: 0.2

#---------------------- Date ----------------------------------------------------#

#04/26/2020

#-------------- General Instrunctions -------------------------------------------#

#Files Included with Install of Program
#--------------------------------------------------------------------------------#
#COPYRIGHT -----> Author and Copyright
#INSTALL -------> Installation Instructions
#Bin -----------> Binary Directory, -chess (Execuatable File), -pngs for pieces on Chess Board 
#Doc -----------> Documentation Directory, -Chess UserManual -Dev User Manual
#Src -----------> Chess.c, Source Code
